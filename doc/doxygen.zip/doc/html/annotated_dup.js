var annotated_dup =
[
    [ "FTRapid", null, [
      [ "FTRapidPacket", "classFTRapid_1_1FTRapidPacket.html", "classFTRapid_1_1FTRapidPacket" ],
      [ "ReceiverSNW", "classFTRapid_1_1ReceiverSNW.html", "classFTRapid_1_1ReceiverSNW" ],
      [ "SenderSNW", "classFTRapid_1_1SenderSNW.html", "classFTRapid_1_1SenderSNW" ]
    ] ],
    [ "HistoryRecorder", null, [
      [ "FileTransferHistory", "classHistoryRecorder_1_1FileTransferHistory.html", "classHistoryRecorder_1_1FileTransferHistory" ],
      [ "TransferHistory", "classHistoryRecorder_1_1TransferHistory.html", "classHistoryRecorder_1_1TransferHistory" ]
    ] ],
    [ "HTTP", null, [
      [ "HTTPServer", "classHTTP_1_1HTTPServer.html", "classHTTP_1_1HTTPServer" ]
    ] ],
    [ "Listener", null, [
      [ "Listener", "classListener_1_1Listener.html", "classListener_1_1Listener" ]
    ] ],
    [ "Logs", null, [
      [ "Guide", "classLogs_1_1Guide.html", "classLogs_1_1Guide" ],
      [ "LogsManager", "classLogs_1_1LogsManager.html", "classLogs_1_1LogsManager" ]
    ] ],
    [ "Main", null, [
      [ "Main", "classMain_1_1Main.html", null ]
    ] ],
    [ "Syncs", null, [
      [ "SyncHandler", "classSyncs_1_1SyncHandler.html", "classSyncs_1_1SyncHandler" ],
      [ "SyncInfo", "classSyncs_1_1SyncInfo.html", "classSyncs_1_1SyncInfo" ],
      [ "Syncs", "classSyncs_1_1Syncs.html", "classSyncs_1_1Syncs" ]
    ] ],
    [ "Transfers", null, [
      [ "FilesWaitingRequestPool", "classTransfers_1_1FilesWaitingRequestPool.html", "classTransfers_1_1FilesWaitingRequestPool" ],
      [ "ThreadPool", "classTransfers_1_1ThreadPool.html", "classTransfers_1_1ThreadPool" ],
      [ "TransferHandler", "classTransfers_1_1TransferHandler.html", "classTransfers_1_1TransferHandler" ]
    ] ],
    [ "UI", null, [
      [ "Interpreter", "classUI_1_1Interpreter.html", "classUI_1_1Interpreter" ]
    ] ]
];