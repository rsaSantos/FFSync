var classFTRapid_1_1ReceiverSNW =
[
    [ "ReceiverSNW", "classFTRapid_1_1ReceiverSNW.html#a9cc56fc65e8fb7a9cd3c56deafbc8537", null ],
    [ "ReceiverSNW", "classFTRapid_1_1ReceiverSNW.html#a16ed58a90f73a81ec5e8d47edefce435", null ],
    [ "collapse", "classFTRapid_1_1ReceiverSNW.html#af463aac17fcbc83875bb39ae3cd66faf", null ],
    [ "requestAndReceive", "classFTRapid_1_1ReceiverSNW.html#a3e28ded2cbfdd1c35c0eaf9b7d951900", null ],
    [ "ADDRESS", "classFTRapid_1_1ReceiverSNW.html#a8b4c4a137025dfab3311d0d79b133f45", null ],
    [ "filename", "classFTRapid_1_1ReceiverSNW.html#acfa127f590f0dae1cbcc819d60e4c52b", null ],
    [ "MODE", "classFTRapid_1_1ReceiverSNW.html#aa98c6e7d4aac612b7ac64e55ab1252f7", null ],
    [ "PORT", "classFTRapid_1_1ReceiverSNW.html#ac8de57eaa3b249904d2d8de0ffbd01ad", null ],
    [ "socket", "classFTRapid_1_1ReceiverSNW.html#ad4b59649ff77a8ebd22e86da699ac5c4", null ]
];