var classFTRapid_1_1SenderSNW =
[
    [ "SenderSNW", "classFTRapid_1_1SenderSNW.html#af63a65313c1f73f55e6516ca0b179d54", null ],
    [ "SenderSNW", "classFTRapid_1_1SenderSNW.html#a8e762e52d17fe40aa432bdd68bd0bd65", null ],
    [ "send", "classFTRapid_1_1SenderSNW.html#aea691041371f0e22048b57228cd739b1", null ],
    [ "split", "classFTRapid_1_1SenderSNW.html#a76be01f12cd2ed76e582518ff731ca4c", null ],
    [ "ADDRESS", "classFTRapid_1_1SenderSNW.html#a7053679ebb01315583c67d747067c046", null ],
    [ "allOK", "classFTRapid_1_1SenderSNW.html#a64b289425deba1a3d40b448d0062637f", null ],
    [ "dataToSend", "classFTRapid_1_1SenderSNW.html#a153748cbdfa249eb7607618353690448", null ],
    [ "FILEPATH", "classFTRapid_1_1SenderSNW.html#ad76babc61b4bb9d8a8b366f90e321287", null ],
    [ "MODE", "classFTRapid_1_1SenderSNW.html#abdef8b46ec0a03ccd25c54381697836c", null ],
    [ "PORT", "classFTRapid_1_1SenderSNW.html#ab4f750f9605a7d94e479a2ed85fb9369", null ],
    [ "socket", "classFTRapid_1_1SenderSNW.html#a9897be3821dfd8ef9f5bb5a117dc9377", null ]
];