var classHTTP_1_1HTTPServer =
[
    [ "HTTPServer", "classHTTP_1_1HTTPServer.html#a3c0ac026a1b025039c470cc57b31c57a", null ],
    [ "closeServer", "classHTTP_1_1HTTPServer.html#a4f2f3b85eb9d9874c2dc5bc5f2efdc13", null ],
    [ "getAllSyncs", "classHTTP_1_1HTTPServer.html#a8153e286c84d05d775d56cbea84bbcb4", null ],
    [ "getHandler", "classHTTP_1_1HTTPServer.html#add7c8736c0271018725d1f85c3f1925d", null ],
    [ "getSync", "classHTTP_1_1HTTPServer.html#a9d16ee8374208239646346357e956548", null ],
    [ "mainMenu", "classHTTP_1_1HTTPServer.html#aa8fd614205197e896fd4f8dcfa9536e9", null ],
    [ "run", "classHTTP_1_1HTTPServer.html#a3d44ebab8d41c30d0733f6500064bc20", null ],
    [ "port", "classHTTP_1_1HTTPServer.html#af3a5df2ccc631392447a589ac4453676", null ],
    [ "serverSocket", "classHTTP_1_1HTTPServer.html#ab14ac29b61d051c95d74edd4c3ed06f3", null ]
];