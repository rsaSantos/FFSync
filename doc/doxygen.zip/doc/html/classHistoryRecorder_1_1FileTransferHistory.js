var classHistoryRecorder_1_1FileTransferHistory =
[
    [ "FileTransferHistory", "classHistoryRecorder_1_1FileTransferHistory.html#a8e18e1c52e0505c2c4728256876f874a", null ],
    [ "FileTransferHistory", "classHistoryRecorder_1_1FileTransferHistory.html#a3874c83b6e27d1387b533e947480ead8", null ],
    [ "getLastUpdated", "classHistoryRecorder_1_1FileTransferHistory.html#abe4d3825302d8848320fa2728cace8ad", null ],
    [ "setBitsPSeg", "classHistoryRecorder_1_1FileTransferHistory.html#a68544389fb189b71a6edca5a3db91b80", null ],
    [ "setLastUpdated", "classHistoryRecorder_1_1FileTransferHistory.html#a5a22491ad16712bcbe157ffea214f74b", null ],
    [ "setTimeOfTransfer", "classHistoryRecorder_1_1FileTransferHistory.html#a6c7fabb6bfb9b01a3e716176b1e4d3f7", null ],
    [ "toHTML", "classHistoryRecorder_1_1FileTransferHistory.html#a2ba095310ded0e821770984958d281bc", null ],
    [ "bitsPSeg", "classHistoryRecorder_1_1FileTransferHistory.html#a07823c6883c3ebd5053baa4cb5e8c5b1", null ],
    [ "lastUpdated", "classHistoryRecorder_1_1FileTransferHistory.html#a6bbc2f3b0edded551e8d8f7001082456", null ],
    [ "timeOfTransfer", "classHistoryRecorder_1_1FileTransferHistory.html#a98097d373a9604fac1035cd92a785237", null ]
];