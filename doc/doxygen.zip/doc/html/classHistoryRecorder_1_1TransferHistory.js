var classHistoryRecorder_1_1TransferHistory =
[
    [ "TransferHistory", "classHistoryRecorder_1_1TransferHistory.html#a3266bf40a6fcef5dce8b1a7be432c803", null ],
    [ "TransferHistory", "classHistoryRecorder_1_1TransferHistory.html#ac813475cf255471cb642ec7ab9066f3d", null ],
    [ "saveTransferHistory", "classHistoryRecorder_1_1TransferHistory.html#af6c4f33b96f9a5f495931946e8696672", null ],
    [ "toHTML", "classHistoryRecorder_1_1TransferHistory.html#a3ffc92c32166c92b56eac7ef3d310e21", null ],
    [ "updateGuide", "classHistoryRecorder_1_1TransferHistory.html#ace44d7a676cbe6d3bbd7c44fa0377cf3", null ],
    [ "updateLogs", "classHistoryRecorder_1_1TransferHistory.html#a50c4432abf2ab985ad553c23fce287f4", null ],
    [ "transfers", "classHistoryRecorder_1_1TransferHistory.html#a38153bdcab2332d5e6a9d0642fd78374", null ]
];