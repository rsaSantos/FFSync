var classLogs_1_1Guide =
[
    [ "Guide", "classLogs_1_1Guide.html#aa8751d2a8e0cdea457bb46c9bdf1a56c", null ],
    [ "Guide", "classLogs_1_1Guide.html#a56246de006df6d56184775a53ce4a905", null ],
    [ "compareLogs", "classLogs_1_1Guide.html#a3b006f839553424d58d7816c5234c76b", null ],
    [ "getBytes", "classLogs_1_1Guide.html#a1695a5e14c32464b868cc3a262586590", null ],
    [ "getGuide", "classLogs_1_1Guide.html#acc0d322fbfe127af4448379f95ed4274", null ],
    [ "guide", "classLogs_1_1Guide.html#a7ebe7637eef89cba4d040d18387a3a6d", null ]
];