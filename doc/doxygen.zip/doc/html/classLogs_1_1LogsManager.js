var classLogs_1_1LogsManager =
[
    [ "LogsManager", "classLogs_1_1LogsManager.html#af37910b208b1331386c609501c74c26d", null ],
    [ "LogsManager", "classLogs_1_1LogsManager.html#a6d6ccabe9e866f3e190fa2b5b31af0d8", null ],
    [ "getBytes", "classLogs_1_1LogsManager.html#ab4e35e4f0497430aab59bd1d1189f37b", null ],
    [ "getCRC32Checksum", "classLogs_1_1LogsManager.html#a085ade975855a59c7a0c882e8e60cafe", null ],
    [ "getLogs", "classLogs_1_1LogsManager.html#a45ba57e3490508e5a7483180a347d04c", null ],
    [ "updateFileLogs", "classLogs_1_1LogsManager.html#a62b76960b4dc901d2880b87ea91c825f", null ],
    [ "updateFileLogsAux", "classLogs_1_1LogsManager.html#a8c45c651af384ed70b52cdab9b939345", null ],
    [ "filepath", "classLogs_1_1LogsManager.html#a872211995c9c50ec9281ca7002cf1e45", null ],
    [ "logs", "classLogs_1_1LogsManager.html#a901ccfadb019c9d45680f0fab3b48553", null ]
];