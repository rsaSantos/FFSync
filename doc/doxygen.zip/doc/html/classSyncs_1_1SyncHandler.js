var classSyncs_1_1SyncHandler =
[
    [ "SyncHandler", "classSyncs_1_1SyncHandler.html#a2cbf0563c563d7bc346d6a828c341e9f", null ],
    [ "closeSocket", "classSyncs_1_1SyncHandler.html#ac7aa557edcad22730b7f43d83f66665b", null ],
    [ "getInfo", "classSyncs_1_1SyncHandler.html#a9f0cc08d75141f8d513e395bf72b6f37", null ],
    [ "inferiorRandomHandler", "classSyncs_1_1SyncHandler.html#adc4f14edc23508390e67bfe8fbfacaef", null ],
    [ "run", "classSyncs_1_1SyncHandler.html#a951e8dd8d29ee62fc1e2b43507b16788", null ],
    [ "superiorRandomHandler", "classSyncs_1_1SyncHandler.html#a7687d6696e9f807b5e039880f56baa3e", null ],
    [ "syncOnce", "classSyncs_1_1SyncHandler.html#aa16e4753375011470d303c4159df818d", null ],
    [ "updateAndSaveLogs", "classSyncs_1_1SyncHandler.html#a9e37d2329a207d83d2aaa2bf9520291b", null ],
    [ "handlerPort", "classSyncs_1_1SyncHandler.html#ad6dc87b8b1ab6cc32a143a427ac0e371", null ],
    [ "isBiggerNumber", "classSyncs_1_1SyncHandler.html#a6403cc7d461cd526aaa77da506659a6f", null ],
    [ "ourLogs", "classSyncs_1_1SyncHandler.html#aef4501c129bef90bb10211fb05239a31", null ],
    [ "ourRandom", "classSyncs_1_1SyncHandler.html#a52b70aec30c4ff3a0a6ebcb3f912ef1a", null ],
    [ "randomNumberPacket", "classSyncs_1_1SyncHandler.html#aed4f090be35c06ed7c2a1a8a8a133036", null ],
    [ "syncHistory", "classSyncs_1_1SyncHandler.html#a36e3d566cc2b451d5418f91b9388c30e", null ],
    [ "syncInfo", "classSyncs_1_1SyncHandler.html#a17adb08ebd6e9fd6aa9c36a59f8e495e", null ],
    [ "syncSocket", "classSyncs_1_1SyncHandler.html#ab77ee72662658fecde0079ebffe58c91", null ]
];