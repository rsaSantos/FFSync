var classSyncs_1_1SyncInfo =
[
    [ "SyncInfo", "classSyncs_1_1SyncInfo.html#a547e8daa1625173b79544581eb2d1ba2", null ],
    [ "activate", "classSyncs_1_1SyncInfo.html#af7708d022dfad2f75b59dd99ad877b07", null ],
    [ "clone", "classSyncs_1_1SyncInfo.html#ad70afc748541850d56eb46a79d7c7ef7", null ],
    [ "deactivate", "classSyncs_1_1SyncInfo.html#a5528b2c2139abcf9c0b2463656124586", null ],
    [ "equals", "classSyncs_1_1SyncInfo.html#a1f68daf7613ef928ae50a930d247a68b", null ],
    [ "getFilename", "classSyncs_1_1SyncInfo.html#a4f5ceb7bfdbfe09f39b80bd1bb4dfa44", null ],
    [ "getFilepath", "classSyncs_1_1SyncInfo.html#a81ea1e3f99e5b53993ffa2f93b93b0a4", null ],
    [ "getId", "classSyncs_1_1SyncInfo.html#ac3d2e8a4ffa0ba5f9e1ddd75d6f8586b", null ],
    [ "getIpAddress", "classSyncs_1_1SyncInfo.html#a396ab6049a410bcfd160c63d62e3c1bc", null ],
    [ "hashCode", "classSyncs_1_1SyncInfo.html#a3226f9b80b55b0582d50fec2b002aaa2", null ],
    [ "toString", "classSyncs_1_1SyncInfo.html#a4392d992af8ac94aa716c278c407d66f", null ],
    [ "active", "classSyncs_1_1SyncInfo.html#ae9d65216e044e8fa96ffad1434ce7c64", null ],
    [ "filename", "classSyncs_1_1SyncInfo.html#a7977dc1139e3b9fe1fb3137486df54ce", null ],
    [ "filepath", "classSyncs_1_1SyncInfo.html#ae410ff2f3a07fb2df301273b015655e3", null ],
    [ "id", "classSyncs_1_1SyncInfo.html#a31780d2898b4344b02d5862984ee2657", null ],
    [ "ipAddress", "classSyncs_1_1SyncInfo.html#a08e826a675ae1a7a1f0e3f4bba5691df", null ]
];