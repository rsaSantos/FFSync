var classSyncs_1_1Syncs =
[
    [ "createSync", "classSyncs_1_1Syncs.html#a23297fc69e6edf6406898bb46858d87d", null ],
    [ "terminate", "classSyncs_1_1Syncs.html#a0c5195ce46e25b3868d25d4d39b4d5e4", null ],
    [ "toString", "classSyncs_1_1Syncs.html#a5a4f081b2ddb94b9827672762f5ebaf4", null ],
    [ "lock", "classSyncs_1_1Syncs.html#a64cbdcfdb4e197c3543a767c90187288", null ],
    [ "syncs", "classSyncs_1_1Syncs.html#a8162c48c9312629c81dff7d7f2891c7e", null ]
];