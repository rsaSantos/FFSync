var classTransfers_1_1ThreadPool =
[
    [ "ThreadPool", "classTransfers_1_1ThreadPool.html#ad628aaa13381021793154e987a9866bb", null ],
    [ "addTransferLogs", "classTransfers_1_1ThreadPool.html#ad9252371b4db5bd5525bb51c13a41237", null ],
    [ "getNMaxFiles", "classTransfers_1_1ThreadPool.html#a5a9b3342e1db08d5e164d56dbe359bff", null ],
    [ "getTransferLogs", "classTransfers_1_1ThreadPool.html#ac19c6e726341d752cc185ed7c5c29dc8", null ],
    [ "inc_dec_nMaxFiles", "classTransfers_1_1ThreadPool.html#a00367767fa39810ee5f91f459220760c", null ],
    [ "waitForAllThreadsToFinish", "classTransfers_1_1ThreadPool.html#a7e26cfa953ff8caa8f9eff92ad155fe2", null ],
    [ "completedTransfers", "classTransfers_1_1ThreadPool.html#a9d3d1c97fb4f254407b755b27a1dbfd7", null ],
    [ "condition", "classTransfers_1_1ThreadPool.html#a7cdae1f6ced0e2bb2ab252aa9db0fd36", null ],
    [ "lock", "classTransfers_1_1ThreadPool.html#a98b617017cc7c756fb01bada7a410933", null ],
    [ "nMaxThreads", "classTransfers_1_1ThreadPool.html#a5fdf5ade8ac0913decc86d561aa8448c", null ]
];