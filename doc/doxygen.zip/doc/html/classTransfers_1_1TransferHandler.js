var classTransfers_1_1TransferHandler =
[
    [ "Listener", "classTransfers_1_1TransferHandler_1_1Listener.html", "classTransfers_1_1TransferHandler_1_1Listener" ],
    [ "ReceiveFile", "classTransfers_1_1TransferHandler_1_1ReceiveFile.html", "classTransfers_1_1TransferHandler_1_1ReceiveFile" ],
    [ "SendFile", "classTransfers_1_1TransferHandler_1_1SendFile.html", "classTransfers_1_1TransferHandler_1_1SendFile" ],
    [ "TransferHandler", "classTransfers_1_1TransferHandler.html#a260c89a1bdb1bca0c441f88a208881e8", null ],
    [ "doIRequest", "classTransfers_1_1TransferHandler.html#a41b993d973f6cc16d10e7ff347c05747", null ],
    [ "getCompleteFilepath", "classTransfers_1_1TransferHandler.html#a31bd2f3d176910256c1bf018b6e15ea7", null ],
    [ "processTransfers", "classTransfers_1_1TransferHandler.html#a5c3f32d2a2518704833362afcf80c17b", null ],
    [ "address", "classTransfers_1_1TransferHandler.html#a006702458fca491330f054188317d5bc", null ],
    [ "biggerNumber", "classTransfers_1_1TransferHandler.html#a55dc2014a9459188cfb809e6b9ace4a4", null ],
    [ "checkProcessTransfers", "classTransfers_1_1TransferHandler.html#a626834ad9478111db40b8dceac00d6df", null ],
    [ "filesWaitingRequestPool", "classTransfers_1_1TransferHandler.html#aa6541dd69030ed7c8b50a73d99b1a105", null ],
    [ "folderPath", "classTransfers_1_1TransferHandler.html#a0f0ca4cec9a5c336cef177fd288a5000", null ],
    [ "handlerPort", "classTransfers_1_1TransferHandler.html#ac51265e114e16c091dd1a3b0ff6faa9f", null ],
    [ "syncSocket", "classTransfers_1_1TransferHandler.html#a8087f5eab03ce2ef81f5de74108f47be", null ],
    [ "threadPool", "classTransfers_1_1TransferHandler.html#ad58098261b9e1c17a5748b3674be57c0", null ],
    [ "transfersGuide", "classTransfers_1_1TransferHandler.html#a2312080dd18ca293d3ae160b449ef513", null ]
];