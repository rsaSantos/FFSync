var classTransfers_1_1TransferHandler_1_1Listener =
[
    [ "listen", "classTransfers_1_1TransferHandler_1_1Listener.html#a9e329d7b483a7285cd9808f81642a6ea", null ],
    [ "run", "classTransfers_1_1TransferHandler_1_1Listener.html#a458aea57b9e6f0cfc304b8c8a5d90908", null ],
    [ "folderPath", "classTransfers_1_1TransferHandler_1_1Listener.html#aaf5e3dc37c62a2049616453e17309808", null ],
    [ "syncSocket", "classTransfers_1_1TransferHandler_1_1Listener.html#a8117566645db6f634734e3e0cdb9ca84", null ]
];