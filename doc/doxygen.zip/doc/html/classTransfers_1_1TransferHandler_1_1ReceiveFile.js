var classTransfers_1_1TransferHandler_1_1ReceiveFile =
[
    [ "ReceiveFile", "classTransfers_1_1TransferHandler_1_1ReceiveFile.html#aef8ab1bd0d5c554ebe9b3c94f58ce186", null ],
    [ "run", "classTransfers_1_1TransferHandler_1_1ReceiveFile.html#a9b6392cbc8de8cae6c8917163c7f00db", null ],
    [ "address", "classTransfers_1_1TransferHandler_1_1ReceiveFile.html#a05ebcd8562ab3f5d6ae8a4c54cd679f7", null ],
    [ "filename", "classTransfers_1_1TransferHandler_1_1ReceiveFile.html#a89c24af8b078a3aaed0d87e772fed6e3", null ],
    [ "folderPath", "classTransfers_1_1TransferHandler_1_1ReceiveFile.html#ac4901bcd9b3564e104f09a5e1cc0deea", null ],
    [ "port", "classTransfers_1_1TransferHandler_1_1ReceiveFile.html#a2c55ecaf8197e34bd62da5c8d1c978e0", null ]
];