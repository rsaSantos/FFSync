var classTransfers_1_1TransferHandler_1_1SendFile =
[
    [ "SendFile", "classTransfers_1_1TransferHandler_1_1SendFile.html#a0fef72e3e259aa7a4104f9b89571e961", null ],
    [ "run", "classTransfers_1_1TransferHandler_1_1SendFile.html#a804e415370a995ebf080f29c5d684b2b", null ],
    [ "filepath", "classTransfers_1_1TransferHandler_1_1SendFile.html#a9bf6f74ed51721a7975f04097cddcb64", null ],
    [ "sendToIpAddress", "classTransfers_1_1TransferHandler_1_1SendFile.html#ac1f6a84b9106e993f1f8ec7b38c3eb6b", null ],
    [ "sendToPort", "classTransfers_1_1TransferHandler_1_1SendFile.html#a2ec5ec7422a85657525d01de891f4c48", null ]
];