var hierarchy =
[
    [ "Transfers.FilesWaitingRequestPool", "classTransfers_1_1FilesWaitingRequestPool.html", null ],
    [ "FTRapid.FTRapidPacket", "classFTRapid_1_1FTRapidPacket.html", null ],
    [ "Logs.Guide", "classLogs_1_1Guide.html", null ],
    [ "Logs.LogsManager", "classLogs_1_1LogsManager.html", null ],
    [ "Main.Main", "classMain_1_1Main.html", null ],
    [ "FTRapid.ReceiverSNW", "classFTRapid_1_1ReceiverSNW.html", null ],
    [ "Runnable", null, [
      [ "HTTP.HTTPServer", "classHTTP_1_1HTTPServer.html", null ],
      [ "Listener.Listener", "classListener_1_1Listener.html", null ],
      [ "Syncs.SyncHandler", "classSyncs_1_1SyncHandler.html", null ],
      [ "Transfers.TransferHandler.Listener", "classTransfers_1_1TransferHandler_1_1Listener.html", null ],
      [ "Transfers.TransferHandler.ReceiveFile", "classTransfers_1_1TransferHandler_1_1ReceiveFile.html", null ],
      [ "Transfers.TransferHandler.SendFile", "classTransfers_1_1TransferHandler_1_1SendFile.html", null ],
      [ "UI.Interpreter", "classUI_1_1Interpreter.html", null ]
    ] ],
    [ "FTRapid.SenderSNW", "classFTRapid_1_1SenderSNW.html", null ],
    [ "Syncs.SyncInfo", "classSyncs_1_1SyncInfo.html", null ],
    [ "Syncs.Syncs", "classSyncs_1_1Syncs.html", null ],
    [ "Transfers.ThreadPool", "classTransfers_1_1ThreadPool.html", null ],
    [ "Transfers.TransferHandler", "classTransfers_1_1TransferHandler.html", null ],
    [ "Serializable", null, [
      [ "HistoryRecorder.FileTransferHistory", "classHistoryRecorder_1_1FileTransferHistory.html", null ],
      [ "HistoryRecorder.TransferHistory", "classHistoryRecorder_1_1TransferHistory.html", null ]
    ] ]
];