var searchData=
[
  ['biggernumber_0',['biggerNumber',['../classTransfers_1_1TransferHandler.html#a55dc2014a9459188cfb809e6b9ace4a4',1,'Transfers::TransferHandler']]],
  ['bitspseg_1',['bitsPSeg',['../classHistoryRecorder_1_1FileTransferHistory.html#a07823c6883c3ebd5053baa4cb5e8c5b1',1,'HistoryRecorder::FileTransferHistory']]],
  ['buffer_5fsize_2',['BUFFER_SIZE',['../classFTRapid_1_1FTRapidPacket.html#a89882b5f14bea6d43db2c7cb49cac634',1,'FTRapid::FTRapidPacket']]]
];
