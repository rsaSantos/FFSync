var searchData=
[
  ['upcomingfiles_0',['upcomingFiles',['../classTransfers_1_1FilesWaitingRequestPool.html#abc30a68654193868e68a098978e83f11',1,'Transfers::FilesWaitingRequestPool']]],
  ['updateandsavelogs_1',['updateAndSaveLogs',['../classSyncs_1_1SyncHandler.html#a9e37d2329a207d83d2aaa2bf9520291b',1,'Syncs::SyncHandler']]],
  ['updatefilelogs_2',['updateFileLogs',['../classLogs_1_1LogsManager.html#a62b76960b4dc901d2880b87ea91c825f',1,'Logs::LogsManager']]],
  ['updatefilelogsaux_3',['updateFileLogsAux',['../classLogs_1_1LogsManager.html#a8c45c651af384ed70b52cdab9b939345',1,'Logs::LogsManager']]],
  ['updateguide_4',['updateGuide',['../classHistoryRecorder_1_1TransferHistory.html#ace44d7a676cbe6d3bbd7c44fa0377cf3',1,'HistoryRecorder::TransferHistory']]],
  ['updatelogs_5',['updateLogs',['../classHistoryRecorder_1_1TransferHistory.html#a50c4432abf2ab985ad553c23fce287f4',1,'HistoryRecorder::TransferHistory']]]
];
