var searchData=
[
  ['nmaxthreads_0',['nMaxThreads',['../classTransfers_1_1ThreadPool.html#a5fdf5ade8ac0913decc86d561aa8448c',1,'Transfers::ThreadPool']]]
];
