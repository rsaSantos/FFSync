var searchData=
[
  ['fileswaitingrequestpool_0',['FilesWaitingRequestPool',['../classTransfers_1_1FilesWaitingRequestPool.html',1,'Transfers']]],
  ['filetransferhistory_1',['FileTransferHistory',['../classHistoryRecorder_1_1FileTransferHistory.html',1,'HistoryRecorder']]],
  ['ftrapidpacket_2',['FTRapidPacket',['../classFTRapid_1_1FTRapidPacket.html',1,'FTRapid']]]
];
