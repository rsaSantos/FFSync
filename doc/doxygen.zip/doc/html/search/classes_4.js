var searchData=
[
  ['listener_0',['Listener',['../classListener_1_1Listener.html',1,'Listener.Listener'],['../classTransfers_1_1TransferHandler_1_1Listener.html',1,'Transfers.TransferHandler.Listener']]],
  ['logsmanager_1',['LogsManager',['../classLogs_1_1LogsManager.html',1,'Logs']]]
];
