var searchData=
[
  ['receivefile_0',['ReceiveFile',['../classTransfers_1_1TransferHandler_1_1ReceiveFile.html',1,'Transfers::TransferHandler']]],
  ['receiversnw_1',['ReceiverSNW',['../classFTRapid_1_1ReceiverSNW.html',1,'FTRapid']]]
];
