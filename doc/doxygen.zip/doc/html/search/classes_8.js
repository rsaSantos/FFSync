var searchData=
[
  ['threadpool_0',['ThreadPool',['../classTransfers_1_1ThreadPool.html',1,'Transfers']]],
  ['transferhandler_1',['TransferHandler',['../classTransfers_1_1TransferHandler.html',1,'Transfers']]],
  ['transferhistory_2',['TransferHistory',['../classHistoryRecorder_1_1TransferHistory.html',1,'HistoryRecorder']]]
];
