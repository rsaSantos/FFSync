var searchData=
[
  ['activate_0',['activate',['../classSyncs_1_1SyncInfo.html#af7708d022dfad2f75b59dd99ad877b07',1,'Syncs::SyncInfo']]],
  ['addtransferlogs_1',['addTransferLogs',['../classTransfers_1_1ThreadPool.html#ad9252371b4db5bd5525bb51c13a41237',1,'Transfers::ThreadPool']]],
  ['addupcomingfiles_2',['addUpcomingFiles',['../classTransfers_1_1FilesWaitingRequestPool.html#a04dc34cfd3ed99b5fcab89c9f02b6ed8',1,'Transfers::FilesWaitingRequestPool']]]
];
