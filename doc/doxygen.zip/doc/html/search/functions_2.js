var searchData=
[
  ['deactivate_0',['deactivate',['../classSyncs_1_1SyncInfo.html#a5528b2c2139abcf9c0b2463656124586',1,'Syncs::SyncInfo']]],
  ['decode_1',['decode',['../classFTRapid_1_1FTRapidPacket.html#af1e77f92792b43676bcffd0986ab802a',1,'FTRapid::FTRapidPacket']]],
  ['doirequest_2',['doIRequest',['../classTransfers_1_1TransferHandler.html#a41b993d973f6cc16d10e7ff347c05747',1,'Transfers::TransferHandler']]]
];
