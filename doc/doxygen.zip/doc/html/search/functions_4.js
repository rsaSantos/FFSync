var searchData=
[
  ['fileswaitingrequestpool_0',['FilesWaitingRequestPool',['../classTransfers_1_1FilesWaitingRequestPool.html#a633f9f2f3cb658f33178c41189bd09a6',1,'Transfers::FilesWaitingRequestPool']]],
  ['filetransferhistory_1',['FileTransferHistory',['../classHistoryRecorder_1_1FileTransferHistory.html#a8e18e1c52e0505c2c4728256876f874a',1,'HistoryRecorder.FileTransferHistory.FileTransferHistory(FileTime lastUpdated, long timeOfTransfer, double bitsPSeg)'],['../classHistoryRecorder_1_1FileTransferHistory.html#a3874c83b6e27d1387b533e947480ead8',1,'HistoryRecorder.FileTransferHistory.FileTransferHistory(FileTransferHistory fileTransferHistory)']]],
  ['ftrapidpacket_2',['FTRapidPacket',['../classFTRapid_1_1FTRapidPacket.html#acf52a880ef5ce86b5cf4d79bf08930b4',1,'FTRapid.FTRapidPacket.FTRapidPacket(FTRapidPacket ftRapidPacket)'],['../classFTRapid_1_1FTRapidPacket.html#abcd2670a87a579fc38032acc821d1c2e',1,'FTRapid.FTRapidPacket.FTRapidPacket(DatagramPacket rcvPacket, int knownMode)']]]
];
