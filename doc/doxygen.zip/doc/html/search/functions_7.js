var searchData=
[
  ['inc_5fdec_5fnmaxfiles_0',['inc_dec_nMaxFiles',['../classTransfers_1_1ThreadPool.html#a00367767fa39810ee5f91f459220760c',1,'Transfers::ThreadPool']]],
  ['inferiorrandomhandler_1',['inferiorRandomHandler',['../classSyncs_1_1SyncHandler.html#adc4f14edc23508390e67bfe8fbfacaef',1,'Syncs::SyncHandler']]]
];
