var searchData=
[
  ['processtransfers_0',['processTransfers',['../classTransfers_1_1TransferHandler.html#a5c3f32d2a2518704833362afcf80c17b',1,'Transfers::TransferHandler']]]
];
