var searchData=
[
  ['sendtoipaddress_0',['sendToIpAddress',['../classTransfers_1_1TransferHandler_1_1SendFile.html#ac1f6a84b9106e993f1f8ec7b38c3eb6b',1,'Transfers::TransferHandler::SendFile']]],
  ['sendtoport_1',['sendToPort',['../classTransfers_1_1TransferHandler_1_1SendFile.html#a2ec5ec7422a85657525d01de891f4c48',1,'Transfers::TransferHandler::SendFile']]],
  ['sequencenumber_2',['sequenceNumber',['../classFTRapid_1_1FTRapidPacket.html#a1751be0a5b1a9d3bde855df72a01c702',1,'FTRapid::FTRapidPacket']]],
  ['serversocket_3',['serverSocket',['../classHTTP_1_1HTTPServer.html#ab14ac29b61d051c95d74edd4c3ed06f3',1,'HTTP::HTTPServer']]],
  ['socket_4',['socket',['../classFTRapid_1_1ReceiverSNW.html#ad4b59649ff77a8ebd22e86da699ac5c4',1,'FTRapid.ReceiverSNW.socket()'],['../classFTRapid_1_1SenderSNW.html#a9897be3821dfd8ef9f5bb5a117dc9377',1,'FTRapid.SenderSNW.socket()']]],
  ['superior_5frandom_5',['SUPERIOR_RANDOM',['../classListener_1_1Listener.html#a72ce8ad6e5a9251dda9eadae1433a989',1,'Listener::Listener']]],
  ['synchistory_6',['syncHistory',['../classSyncs_1_1SyncHandler.html#a36e3d566cc2b451d5418f91b9388c30e',1,'Syncs::SyncHandler']]],
  ['syncinfo_7',['syncInfo',['../classSyncs_1_1SyncHandler.html#a17adb08ebd6e9fd6aa9c36a59f8e495e',1,'Syncs::SyncHandler']]],
  ['syncs_8',['syncs',['../classSyncs_1_1Syncs.html#a8162c48c9312629c81dff7d7f2891c7e',1,'Syncs::Syncs']]],
  ['syncsocket_9',['syncSocket',['../classSyncs_1_1SyncHandler.html#ab77ee72662658fecde0079ebffe58c91',1,'Syncs.SyncHandler.syncSocket()'],['../classTransfers_1_1TransferHandler.html#a8087f5eab03ce2ef81f5de74108f47be',1,'Transfers.TransferHandler.syncSocket()'],['../classTransfers_1_1TransferHandler_1_1Listener.html#a8117566645db6f634734e3e0cdb9ca84',1,'Transfers.TransferHandler.Listener.syncSocket()']]]
];
