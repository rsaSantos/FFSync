var searchData=
[
  ['upcomingfiles_0',['upcomingFiles',['../classTransfers_1_1FilesWaitingRequestPool.html#abc30a68654193868e68a098978e83f11',1,'Transfers::FilesWaitingRequestPool']]]
];
