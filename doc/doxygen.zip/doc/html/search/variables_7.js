var searchData=
[
  ['handlerport_0',['handlerPort',['../classSyncs_1_1SyncHandler.html#ad6dc87b8b1ab6cc32a143a427ac0e371',1,'Syncs.SyncHandler.handlerPort()'],['../classTransfers_1_1TransferHandler.html#ac51265e114e16c091dd1a3b0ff6faa9f',1,'Transfers.TransferHandler.handlerPort()']]],
  ['http_5ffilepath_1',['HTTP_FILEPATH',['../classHTTP_1_1HTTPServer.html#afb4730b320a649fd431bb43e6e7ded8f',1,'HTTP::HTTPServer']]]
];
